<?php
$pesan = htmlspecialchars($_POST['pesan']);
$filename = "pesan/pesan_" . time() . ".txt";
file_put_contents($filename, $pesan);
header("Location: index.html");
?>
