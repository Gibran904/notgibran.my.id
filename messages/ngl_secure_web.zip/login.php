<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head><title>Login Admin</title></head>
<body>
  <h2>Login Dulu Biar Bisa Lihat Pesan</h2>
  <form action="auth.php" method="POST">
    <input type="text" name="username" placeholder="Username" required><br>
    <input type="password" name="password" placeholder="Password" required><br>
    <button type="submit">Login</button>
  </form>
</body>
</html>
