<?php
session_start();
if (!isset($_SESSION['login'])) {
  header("Location: login.php");
  exit;
}

echo "<h1>Pesan Masuk</h1>";
foreach (glob("pesan/*.txt") as $file) {
  echo "<p>" . htmlspecialchars(file_get_contents($file)) . "</p><hr>";
}
echo '<a href="logout.php">Logout</a>';
?>
